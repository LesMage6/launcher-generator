# zone.py
# Définition simple des zones et utilitaires

class Zone:
    def __init__(self, name, ztype, reward_mult=1, stat_mult=1):
        self.name = name
        self.type = ztype  # "combat", "elite", "conversion", "shop", "event"
        self.reward_mult = reward_mult
        self.stat_mult = stat_mult

# Zones par défaut
ZONES = [
    Zone("Combat", "combat", reward_mult=1, stat_mult=1),
    Zone("Élite", "elite", reward_mult=3, stat_mult=3),
    Zone("Conversion", "conversion", reward_mult=3, stat_mult=4),  # rewards triple + extra diamants gérés ailleurs
    Zone("Marchand", "shop", reward_mult=0, stat_mult=1),
    Zone("Évènement", "event", reward_mult=0, stat_mult=1),
]