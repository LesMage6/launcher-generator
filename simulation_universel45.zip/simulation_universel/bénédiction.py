# benediction.py
# Gestion des bénédictions (BETA)

class Benediction:
    def __init__(self, id, name, chemin, description, effect_key):
        self.id = id
        self.name = name
        self.chemin = chemin
        self.description = description
        self.effect_key = effect_key  # clé pour appliquer l'effet dans le moteur

# Liste des bénédictions BETA
BENEDICTIONS = [
    # Destructeur
    Benediction("des_def12", "Peau de Fer", "Destructeur",
                "Augmente la DEF de tous les alliés de 12%.", "des_def12"),
    Benediction("des_onhit_def2", "Résilience Brutale", "Destructeur",
                "En subissant des DMG, augmente la DEF de 2%.", "des_onhit_def2"),
    Benediction("des_stack", "Force Inflexible", "Destructeur",
                "Augmente l'ATQ de 4% et la DEF de 2% pour chaque bénédiction du Destructeur.",
                "des_stack"),

    # Chasseur
    Benediction("cha_speed12", "Vent Rapide", "Chasseur",
                "Augmente la VIT de tous les alliés de 12%.", "cha_speed12"),
    Benediction("cha_aggro_lowhp", "Furtivité", "Chasseur",
                "Baisse les chances de se faire attaquer de l'allié le plus fragile de 20%.",
                "cha_aggro_lowhp"),
    Benediction("cha_crit10", "Instincts Aiguisés", "Chasseur",
                "Augmente les Taux Crit de 10%.", "cha_crit10"),

    # Soigneur
    Benediction("soi_hp12", "Vitalité Sacrée", "Soigneur",
                "Augmente les PV Max de tous les alliés de 12%.", "soi_hp12"),
    Benediction("soi_onheal_hp2", "Croissance", "Soigneur",
                "En recevant des soins, augmente les PV Max de 2%.", "soi_onheal_hp2"),
    Benediction("soi_heal8", "Main Divine", "Soigneur",
                "Augmente les soins prodigués par les alliés de 8%.", "soi_heal8"),
]

# Helper pour appliquer effets (appelé depuis main.py / BattleSystem)
def apply_static_benedictions_to_team(run_state, allies):
    """
    Applique les effets statiques des bénédictions au moment de la création d'une équipe.
    - run_state: objet RunState
    - allies: liste d'Entity
    """
    # Parcours des bénédictions acquises
    for b in getattr(run_state, "benedictions", []):
        key = getattr(b, "effect_key", None)
        if key == "des_def12":
            for a in allies:
                a.defense = int(a.defense * 1.12)
        elif key == "cha_speed12":
            for a in allies:
                a.speed = int(a.speed * 1.12)
        elif key == "cha_crit10":
            for a in allies:
                a.crit_rate = min(1.0, a.crit_rate + 0.10)
        elif key == "soi_hp12":
            for a in allies:
                a.max_hp = int(a.max_hp * 1.12)
                a.hp = min(a.hp + int(a.max_hp * 0.12), a.max_hp)
        elif key == "soi_heal8":
            # stocker un flag sur run_state pour augmenter soins
            run_state.bonus_heal_mult = getattr(run_state, "bonus_heal_mult", 1.0) * 1.08
        # les autres bénédictions (on_hit / on_heal / stack) sont gérées dynamiquement dans BattleSystem