# main.py
import tkinter as tk
import random
import os

# External modules (ensure these files exist in the same package)
# benediction.py must provide BENEDICTIONS and apply_static_benedictions_to_team
# zone.py must provide ZONES
# profile_core.py must provide load_profile, save_profile, ensure_game_data, create_profile, list_profiles
try:
    from benediction import BENEDICTIONS, apply_static_benedictions_to_team
except Exception:
    BENEDICTIONS = []
    def apply_static_benedictions_to_team(run_state, allies): pass

try:
    from zone import ZONES
except Exception:
    class Zone:
        def __init__(self, name, ztype): self.name = name; self.type = ztype
    ZONES = [Zone("Combat", "combat"), Zone("Élite", "elite"), Zone("Conversion", "conversion"),
             Zone("Marchand", "shop"), Zone("Évènement", "event")]

import profile_core
from profile_core import load_profile, save_profile, ensure_game_data, create_profile, list_profiles

# ----------------------------
# Configuration / profile
# ----------------------------
# Default profile name (you can change this or add a profile selection UI)
PROFILE_NAME = "default"

# Ensure profile exists and has game data
profile = load_profile(PROFILE_NAME)
profile = ensure_game_data(profile)
save_profile(PROFILE_NAME, profile)

# ----------------------------
# Constants and definitions
# ----------------------------
VOIES = ["Destructeur", "Chasseur", "Soigneur"]

ALLY_DEFS = [
    {"name": "Raton Laveur", "max_hp": 120, "atk": 20, "def": 10, "crit_rate": 0.05, "crit_dmg": 1.5, "aggro": 10, "speed": 12},
    {"name": "Chien", "max_hp": 150, "atk": 18, "def": 12, "crit_rate": 0.05, "crit_dmg": 1.5, "aggro": 20, "speed": 10},
    {"name": "Fantôme Gentil", "max_hp": 100, "atk": 10, "def": 8, "crit_rate": 0.0, "crit_dmg": 1.5, "aggro": 5, "speed": 11},
    {"name": "Souris", "max_hp": 90, "atk": 16, "def": 8, "crit_rate": 0.1, "crit_dmg": 1.6, "aggro": 8, "speed": 13},
    {"name": "Animal Masqué", "max_hp": 130, "atk": 18, "def": 10, "crit_rate": 0.15, "crit_dmg": 1.8, "aggro": 12, "speed": 11},
    {"name": "Loup Draconique", "max_hp": 160, "atk": 22, "def": 12, "crit_rate": 0.12, "crit_dmg": 1.7, "aggro": 15, "speed": 11},
    {"name": "Guépard", "max_hp": 140, "atk": 19, "def": 11, "crit_rate": 0.08, "crit_dmg": 1.6, "aggro": 40, "speed": 14},
]

ALLY_POOL = [d["name"] for d in ALLY_DEFS]

ENEMY_NAMES = ["Slime", "Gobelin", "Spectre", "Golem", "Démon Mineur", "Loup Sombre"]

EVENTS = ["Voyageur Minérale", "Voyageur Chanceux", "Voyageur Perçant"]

# ----------------------------
# Run state
# ----------------------------
class RunState:
    def __init__(self, world_name, team_names, voie, profile_name=PROFILE_NAME):
        self.world_name = world_name
        self.team_names = team_names or []
        self.voie = voie
        self.floor = 1
        self.combats_won = 0

        # persistent bonuses
        self.bonus_hp = 0
        self.bonus_crit = 0.0
        self.bonus_atk_mult = 1.0
        self.benedictions = []  # list of Benediction objects
        self.diamants = 100

        # zone flags
        self.elite = False
        self.conversion = False

        # profile reference
        self.profile_name = profile_name

# ----------------------------
# Entity
# ----------------------------
class Entity:
    def __init__(self, name, max_hp, atk, defense, crit_rate, crit_dmg, aggro, speed, is_ally):
        self.name = name
        self.max_hp = max_hp
        self.hp = max_hp
        self.atk = atk
        self.defense = defense
        self.crit_rate = crit_rate
        self.crit_dmg = crit_dmg
        self.aggro = aggro
        self.speed = speed
        self.is_ally = is_ally

        self.action_bar = 0
        self.alive = True

        self.energy = 0
        self.frozen = False
        self.vent = False

    def get_atk(self):
        atk = self.atk
        if self.vent:
            atk = int(atk * 0.9)
        return atk

    def take_damage(self, amount, battle, source=None):
        if not self.alive:
            return 0
        dmg = max(1, int(amount * (100 / (100 + self.defense))))
        old_hp = self.hp
        self.hp -= dmg
        if self.hp <= 0:
            self.hp = 0
            self.alive = False
            battle.log(f"{self.name} est K.O.")
        else:
            battle.log(f"{self.name} subit {dmg} dégâts. ({old_hp} → {self.hp})")

        # triggers
        battle.on_hp_change(self, dmg, source)

        # Guépard revive
        if self.name == "Guépard":
            if hasattr(self, "revive_charge") and self.revive_charge and not self.alive:
                self.revive_charge = False
                self.hp = int(self.max_hp * 0.80)
                self.alive = True
                battle.log(f"{self.name} refuse de mourir et se relève avec 80% de ses PV !")

        return dmg

    def heal(self, amount, battle):
        if not self.alive:
            return
        old_hp = self.hp
        self.hp = min(self.max_hp, self.hp + amount)
        gain = self.hp - old_hp
        if gain > 0:
            battle.log(f"{self.name} récupère {gain} PV. ({old_hp} → {self.hp})")
            battle.on_hp_change(self, -gain, None)

    def basic_attack(self, target, battle, trigger_follow=True):
        if not self.alive or not target.alive:
            return
        is_crit = random.random() < self.crit_rate
        dmg = self.get_atk()
        if is_crit:
            dmg = int(dmg * self.crit_dmg)
        battle.log(f"{self.name} attaque {target.name}." + (" (CRITIQUE)" if is_crit else ""))
        dealt = target.take_damage(dmg, battle, source=self)

        # Animal Masqué energy on ally attack
        if self.is_ally:
            am = battle.get_ally("Animal Masqué")
            if am and am.alive:
                am.animal_masque_on_ally_attack(battle)

        # Dog follow-up
        if self.is_ally and trigger_follow:
            dog = battle.get_ally("Chien")
            if dog and dog.alive and dog is not self:
                battle.log(f"{dog.name} suit l'attaque de {self.name} !")
                dog.follow_attack(battle)

        return dealt

# ----------------------------
# Special abilities (bound to Entity via assignment)
# ----------------------------
def raton_turn_start(self, battle):
    if not self.alive:
        return
    target = battle.pick_random_enemy()
    if target:
        battle.log(f"{self.name} attaque automatiquement au début de son tour.")
        self.basic_attack(target, battle)
    self.energy += 10
    battle.log(f"{self.name} gagne 10 énergie ({self.energy}/40).")
    if self.energy >= 40:
        self.energy -= 40
        battle.log(f"{self.name} déclenche une attaque massive sur tous les ennemis !")
        for e in battle.enemies:
            if e.alive:
                self.basic_attack(e, battle, trigger_follow=False)
Entity.raton_turn_start = raton_turn_start

def dog_turn_start(self, battle):
    if not self.alive:
        return
    target = battle.pick_random_enemy()
    if target:
        battle.log(f"{self.name} inflige des dégâts mineurs au début de son tour.")
        dmg = int(self.get_atk() * 0.7)
        target.take_damage(dmg, battle, source=self)
Entity.dog_turn_start = dog_turn_start

def dog_follow_attack(self, battle):
    target = battle.pick_random_enemy()
    if target:
        battle.log(f"{self.name} attaque en soutien !")
        dmg = int(self.get_atk() * 0.8)
        target.take_damage(dmg, battle, source=self)
Entity.follow_attack = dog_follow_attack

def fantome_turn(self, battle):
    if not self.alive:
        return
    ally = battle.pick_random_ally()
    if ally:
        heal_amount = int(ally.max_hp * 0.20)
        battle.log(f"{self.name} soigne {ally.name}.")
        ally.heal(heal_amount, battle)
Entity.fantome_turn = fantome_turn

def souris_turn(self, battle, target):
    if not self.alive or not target.alive:
        return
    battle.log(f"{self.name} attaque rapidement {target.name}.")
    self.basic_attack(target, battle)
    if not hasattr(self, "charges"):
        self.charges = 0
    self.charges += 1
    battle.log(f"{self.name} gagne 1 charge ({self.charges}/6).")
    if self.charges >= 6:
        self.charges = 0
        battle.log(f"{self.name} libère son pouvoir : buff ATQ + VIT pour tous les alliés !")
        for ally in battle.allies:
            if ally.alive:
                atk_buff = int(self.atk * 0.20)
                speed_buff = int(self.speed * 0.15)
                ally.atk += atk_buff
                ally.speed += speed_buff
                battle.log(f"{ally.name} gagne +{atk_buff} ATQ et +{speed_buff} VIT.")
Entity.souris_turn = souris_turn

def animal_masque_passive(self, battle):
    if not hasattr(self, "passive_applied"):
        self.passive_applied = True
        battle.log(f"{self.name} inspire l'équipe : +ATQ et +DMG Crit pour tous les alliés.")
        for ally in battle.allies:
            ally.atk = int(ally.atk * 1.10)
            ally.crit_dmg = ally.crit_dmg + 0.20
Entity.animal_masque_passive = animal_masque_passive

def animal_masque_on_ally_attack(self, battle):
    if not self.alive:
        return
    if not hasattr(self, "energy"):
        self.energy = 0
    self.energy += 10
    battle.log(f"{self.name} gagne 10 énergie ({self.energy}/60).")
    if self.energy >= 60:
        self.energy = 0
        battle.log(f"{self.name} libère son pouvoir : +24% VIT alliés, -15% ATQ ennemis.")
        for ally in battle.allies:
            ally.speed = int(ally.speed * 1.24)
        for enemy in battle.enemies:
            enemy.atk = int(enemy.atk * 0.85)
Entity.animal_masque_on_ally_attack = animal_masque_on_ally_attack

def loup_draconique_start(self, battle):
    if not hasattr(self, "charges"):
        self.charges = 3
    battle.log(f"{self.name} commence le combat avec 3 charges.")
Entity.loup_draconique_start = loup_draconique_start

def loup_draconique_turn(self, battle):
    if not self.alive:
        return
    if not hasattr(self, "charges"):
        self.charges = 3
    if self.charges < 5:
        self.charges += 1
        battle.log(f"{self.name} accumule une charge ({self.charges}/5).")
    if self.charges == 5 and not hasattr(self, "buff_applied"):
        self.buff_applied = True
        battle.log(f"{self.name} entre en frénésie draconique !")
        self.atk = int(self.atk * 1.35)
        self.crit_rate = min(1.0, self.crit_rate + 0.60)
        battle.log(f"ATQ et Taux Crit de {self.name} sont fortement augmentés.")
Entity.loup_draconique_turn = loup_draconique_turn

def guepard_init(self):
    self.revive_charge = True
Entity.guepard_init = guepard_init

# ----------------------------
# Voie system
# ----------------------------
class VoieSystem:
    def __init__(self, battle):
        self.battle = battle
        self.chasseur_actions = 0
        self.soigneur_charges = 0

    def trigger_destructeur(self, lost_hp):
        self.battle.log(f"[Voie Destructeur] Dégâts de zone de {lost_hp}.")
        for e in self.battle.enemies:
            if e.alive:
                e.take_damage(lost_hp, self.battle)

    def trigger_chasseur_action(self):
        self.chasseur_actions += 1
        if self.chasseur_actions >= 12:
            self.chasseur_actions = 0
            self.battle.log("[Voie Chasseur] Dégâts de zone + Vent (-10% ATQ).")
            for e in self.battle.enemies:
                if e.alive:
                    e.take_damage(15, self.battle)
                    e.vent = True
                    self.battle.log(f"{e.name} subit Vent : ATQ réduite.")

    def trigger_soigneur_charge(self):
        self.soigneur_charges += 1
        self.battle.log(f"[Voie Soigneur] Charge +1 ({self.soigneur_charges}/4).")
        if self.soigneur_charges >= 4:
            self.soigneur_charges = 0
            self.battle.log("[Voie Soigneur] Soin de zone.")
            for a in self.battle.allies:
                if a.alive:
                    a.heal(int(a.max_hp * 0.15), self.battle)

# ----------------------------
# Autosave helper
# ----------------------------
def autosave_run(profile_name, run_state):
    try:
        profile = load_profile(profile_name)
        profile = ensure_game_data(profile)
        profile["game"]["world"] = run_state.world_name
        profile["game"]["team"] = run_state.team_names
        profile["game"]["voie"] = run_state.voie
        profile["game"]["floor"] = run_state.floor
        profile["game"]["diamants"] = run_state.diamants
        # store benedictions by id if available
        profile["game"]["benedictions"] = [getattr(b, "id", getattr(b, "effect_key", str(b))) for b in run_state.benedictions]
        profile["game"]["bonus_hp"] = run_state.bonus_hp
        profile["game"]["bonus_crit"] = run_state.bonus_crit
        profile["game"]["bonus_atk_mult"] = run_state.bonus_atk_mult
        profile["game"]["bonus_heal_mult"] = getattr(run_state, "bonus_heal_mult", 1.0)
        save_profile(profile_name, profile)
    except Exception as e:
        print("Autosave failed:", e)

# ----------------------------
# Battle system
# ----------------------------
class BattleSystem:
    def __init__(self, root, voie, log_box, allies_frame, enemies_frame,
                 team_names=None, run_state=None):
        self.root = root
        self.selected_voie = voie
        self.log_box = log_box
        self.allies_frame = allies_frame
        self.enemies_frame = enemies_frame

        self.run_state = run_state
        self.team_names = team_names or []

        self.allies = []
        self.enemies = []

        self.voies = VoieSystem(self)
        self.current_actor = None

        self.widgets_allies = []
        self.widgets_enemies = []
        self.entity_widget_map = {}

        self.create_teams()
        self.refresh_ui()

    def log(self, text):
        if self.log_box:
            self.log_box.insert(tk.END, text + "\n")
            self.log_box.see(tk.END)
        else:
            print(text)

    def create_teams(self):
        # Allies
        if self.team_names:
            for name in self.team_names:
                data = next((d for d in ALLY_DEFS if d["name"] == name), None)
                if not data:
                    continue
                ent = Entity(data["name"], data["max_hp"], data["atk"], data["def"],
                             data["crit_rate"], data["crit_dmg"], data["aggro"], data["speed"], True)
                if self.run_state:
                    ent.max_hp += self.run_state.bonus_hp
                    ent.hp = ent.max_hp
                    ent.crit_rate = min(1.0, ent.crit_rate + self.run_state.bonus_crit)
                    ent.atk = int(ent.atk * self.run_state.bonus_atk_mult)
                if ent.name == "Guépard":
                    ent.guepard_init()
                if ent.name == "Loup Draconique":
                    ent.loup_draconique_start(self)
                self.allies.append(ent)
        else:
            for data in ALLY_DEFS:
                ent = Entity(data["name"], data["max_hp"], data["atk"], data["def"],
                             data["crit_rate"], data["crit_dmg"], data["aggro"], data["speed"], True)
                self.allies.append(ent)

        # apply static benedictions
        if self.run_state and getattr(self.run_state, "benedictions", []):
            apply_static_benedictions_to_team(self.run_state, self.allies)

        # Animal Masqué passive
        am = self.get_ally("Animal Masqué")
        if am:
            am.animal_masque_passive(self)

        # Enemies
        enemy_count = random.randint(2, 4)
        for _ in range(enemy_count):
            name = random.choice(ENEMY_NAMES)
            max_hp = random.randint(80, 140)
            atk = random.randint(12, 20)
            defense = random.randint(5, 12)
            crit_rate = 0.05
            crit_dmg = 1.5
            aggro = random.randint(5, 20)
            speed = random.randint(8, 12)

            mult = 1
            if self.run_state and getattr(self.run_state, "elite", False):
                mult = 3
            if self.run_state and getattr(self.run_state, "conversion", False):
                mult = 4

            max_hp *= mult
            atk *= mult
            defense *= mult

            self.enemies.append(Entity(name, max_hp, atk, defense, crit_rate, crit_dmg, aggro, speed, False))

        self.log(f"Voie sélectionnée : {self.selected_voie}")
        self.log("Le combat commence !")

    # Utilities
    def get_ally(self, name):
        for a in self.allies:
            if a.name == name:
                return a
        return None

    def pick_random_enemy(self):
        alive = [e for e in self.enemies if e.alive]
        return random.choice(alive) if alive else None

    def pick_random_ally(self):
        alive = [a for a in self.allies if a.alive]
        return random.choice(alive) if alive else None

    def pick_target_by_aggro(self):
        alive = [a for a in self.allies if a.alive]
        if not alive:
            return None
        total_aggro = sum(a.aggro for a in alive)
        r = random.uniform(0, total_aggro)
        acc = 0
        for a in alive:
            acc += a.aggro
            if r <= acc:
                return a
        return alive[-1]

    # Triggers
    def on_hp_change(self, target, dmg, source):
        # dmg > 0 = loss, dmg < 0 = heal
        if self.selected_voie == "Destructeur" and target.is_ally and dmg > 0:
            self.voies.trigger_destructeur(dmg)
        if self.selected_voie == "Soigneur" and dmg != 0:
            self.voies.trigger_soigneur_charge()

        fg = self.get_ally("Fantôme Gentil")
        if fg and fg.alive and dmg != 0:
            fg.energy += 6
            self.log(f"{fg.name} gagne 6 énergie ({fg.energy}/36).")
            if fg.energy >= 36:
                fg.energy -= 36
                self.freeze_random_enemy()

        # dynamic benedictions
        if self.run_state:
            for b in getattr(self.run_state, "benedictions", []):
                key = getattr(b, "effect_key", None)
                if key == "des_onhit_def2" and target.is_ally and dmg > 0:
                    for a in self.allies:
                        a.defense = int(a.defense * 1.02)
                    self.log("[Bénédiction] Résilience Brutale : DEF alliés +2%")
                elif key == "des_stack":
                    count = sum(1 for bb in self.run_state.benedictions if getattr(bb, "chemin", "") == "Destructeur")
                    if count > 0:
                        for a in self.allies:
                            a.atk = int(a.atk * (1 + 0.04 * count))
                            a.defense = int(a.defense * (1 + 0.02 * count))

    def freeze_random_enemy(self):
        target = self.pick_random_enemy()
        if target:
            target.frozen = True
            self.log(f"{target.name} est gelé et perdra son prochain tour.")

    # Turn engine
    def start_turn_cycle(self):
        self.process_next_turn()

    def process_next_turn(self):
        if self.check_end():
            return
        while True:
            for ent in self.allies + self.enemies:
                if ent.alive:
                    ent.action_bar += ent.speed
            ready = [e for e in self.allies + self.enemies if e.alive and e.action_bar >= 100]
            if ready:
                break
        current = max(ready, key=lambda x: x.action_bar)
        current.action_bar = 0

        # Loup Draconique start-of-turn
        if current.is_ally and current.name == "Loup Draconique":
            current.loup_draconique_turn(self)

        if current.frozen:
            self.log(f"{current.name} est gelé et perd son tour.")
            current.frozen = False
            self.refresh_ui()
            self.root.after(200, self.process_next_turn)
            return

        if current.is_ally:
            self.log(f"--- Tour de {current.name} (Allié) ---")
            self.current_actor = current
            self.enable_enemy_selection()
            return
        else:
            self.log(f"--- Tour de {current.name} (Ennemi) ---")
            target = self.pick_target_by_aggro()
            if target:
                current.basic_attack(target, self, trigger_follow=False)
            self.refresh_ui()
            self.root.after(200, self.process_next_turn)

    # Selection
    def enable_enemy_selection(self):
        self.refresh_ui(clickable=True)

    def on_enemy_clicked(self, enemy):
        actor = self.current_actor
        if not actor or not actor.alive:
            return
        if actor.name == "Raton Laveur":
            actor.raton_turn_start(self)
            actor.basic_attack(enemy, self)
        elif actor.name == "Chien":
            actor.dog_turn_start(self)
            actor.basic_attack(enemy, self)
        elif actor.name == "Fantôme Gentil":
            actor.fantome_turn(self)
            actor.basic_attack(enemy, self)
        elif actor.name == "Souris":
            actor.souris_turn(self, enemy)
        else:
            actor.basic_attack(enemy, self)

        if actor.is_ally and self.selected_voie == "Chasseur":
            self.voies.trigger_chasseur_action()

        self.refresh_ui()
        # autosave after action if run_state present
        if self.run_state:
            autosave_run(self.run_state.profile_name, self.run_state)
        self.root.after(200, self.process_next_turn)

    # UI
    def refresh_ui(self, clickable=False):
        for w in getattr(self, "widgets_allies", []):
            try: w.destroy()
            except: pass
        for w in getattr(self, "widgets_enemies", []):
            try: w.destroy()
            except: pass

        self.widgets_allies = []
        self.widgets_enemies = []
        self.entity_widget_map = {}

        # Allies
        row = 0
        for a in self.allies:
            frame_ent = tk.Frame(self.allies_frame, bg="#1e1e1e")
            frame_ent.grid(row=row, column=0, sticky="w", pady=5)
            name_lbl = tk.Label(frame_ent, text=a.name, font=("Arial", 11), fg="white", bg="#1e1e1e")
            name_lbl.pack(side="left")
            bar_w = 180
            canvas = tk.Canvas(frame_ent, width=bar_w, height=14, bg="#333333", highlightthickness=0)
            canvas.pack(side="left", padx=8)
            hp_ratio = a.hp / a.max_hp if a.max_hp > 0 else 0
            fill_w = int(bar_w * hp_ratio)
            if hp_ratio > 0.6:
                color = "#4caf50"
            elif hp_ratio > 0.3:
                color = "#ffb300"
            else:
                color = "#ef5350"
            canvas.create_rectangle(0, 0, fill_w, 14, fill=color, width=0)
            canvas.create_text(bar_w//2, 7, text=f"{a.hp}/{a.max_hp}", fill="white", font=("Arial", 9))
            self.widgets_allies.append(frame_ent)
            self.entity_widget_map[a] = frame_ent
            row += 1

        # Enemies
        row = 0
        for e in self.enemies:
            text = f"{e.name}\nPV: {e.hp}/{e.max_hp}\nATQ:{e.get_atk()} DEF:{e.defense}\nVIT:{e.speed}"
            if not e.alive:
                text += "\n[K.O.]"
            if clickable and e.alive:
                btn = tk.Button(self.enemies_frame, text=text, font=("Arial", 11),
                                command=lambda ent=e: self.on_enemy_clicked(ent),
                                fg="white", bg="#333333", justify="left")
                btn.grid(row=row, column=0, sticky="w", pady=5)
                self.widgets_enemies.append(btn)
                self.entity_widget_map[e] = btn
            else:
                lbl = tk.Label(self.enemies_frame, text=text, font=("Arial", 11),
                               fg="white" if e.alive else "#777777", bg="#1e1e1e", justify="left")
                lbl.grid(row=row, column=0, sticky="w", pady=5)
                self.widgets_enemies.append(lbl)
                self.entity_widget_map[e] = lbl
            row += 1

    # End of combat
    def check_end(self):
        allies_alive = any(a.alive for a in self.allies)
        enemies_alive = any(e.alive for e in self.enemies)

        if not allies_alive:
            self.log("Tous les alliés sont K.O. Défaite.")
            # autosave defeat
            if self.run_state:
                autosave_run(self.run_state.profile_name, self.run_state)
            return True

        if not enemies_alive:
            self.log("Tous les ennemis sont vaincus. Victoire !")
            if self.run_state:
                if getattr(self.run_state, "elite", False):
                    self.run_state.diamants += 150
                    self.run_state.elite = False
                if getattr(self.run_state, "conversion", False):
                    self.run_state.diamants += 200
                    self.run_state.conversion = False
                self.run_state.combats_won += 1
                self.run_state.floor += 1
                autosave_run(self.run_state.profile_name, self.run_state)
                self.root.after(600, lambda: open_benediction_choice(self.root, self.run_state))
            return True
        return False

# ----------------------------
# UI flow
# ----------------------------
def clear_window(root):
    for w in root.winfo_children():
        try: w.destroy()
        except: pass

def open_menu(root):
    clear_window(root)
    root.configure(bg="#1e1e1e")
    tk.Label(root, text="Simulation Universel", font=("Arial", 28),
             fg="white", bg="#1e1e1e").pack(pady=40)
    tk.Button(root, text="PLAY", font=("Arial", 20), width=15,
              command=lambda: open_world_select(root)).pack(pady=20)
    tk.Button(root, text="QUIT", font=("Arial", 20), width=15,
              command=root.destroy).pack(pady=20)

def open_world_select(root):
    clear_window(root)
    root.configure(bg="#1e1e1e")
    tk.Label(root, text="Choisissez un Monde", font=("Arial", 24),
             fg="white", bg="#1e1e1e").pack(pady=20)
    tk.Button(root, text="Monde I", font=("Arial", 18), width=20,
              command=lambda: open_team_select(root, "Monde I")).pack(pady=10)

def open_team_select(root, world_name):
    clear_window(root)
    root.configure(bg="#1e1e1e")
    tk.Label(root, text=f"{world_name} - Choisissez votre équipe (4 alliés)",
             font=("Arial", 20), fg="white", bg="#1e1e1e").pack(pady=10)
    selected = []
    frame = tk.Frame(root, bg="#1e1e1e")
    frame.pack(pady=10)
    def toggle_ally(name, btn):
        if name in selected:
            selected.remove(name)
            btn.config(relief="raised", bg="#333333")
        else:
            if len(selected) >= 4:
                return
            selected.append(name)
            btn.config(relief="sunken", bg="#4fc3f7")
    for name in ALLY_POOL:
        b = tk.Button(frame, text=name, font=("Arial", 14), width=20, bg="#333333", fg="white")
        b.config(command=lambda n=name, btn=b: toggle_ally(n, btn))
        b.pack(pady=5)
    def confirm_team():
        if len(selected) != 4:
            return
        open_voie_select(root, world_name, selected)
    tk.Button(root, text="Valider l'équipe", font=("Arial", 16),
              command=confirm_team).pack(pady=20)

def open_voie_select(root, world_name, team):
    clear_window(root)
    root.configure(bg="#1e1e1e")
    tk.Label(root, text="Choisissez une Voie", font=("Arial", 24),
             fg="white", bg="#1e1e1e").pack(pady=20)
    frame = tk.Frame(root, bg="#1e1e1e")
    frame.pack()
    for voie in VOIES:
        tk.Button(frame, text=voie, font=("Arial", 18), width=20,
                  command=lambda v=voie: start_run(root, world_name, team, v)).pack(pady=10)

def start_run(root, world_name, team_names, voie):
    run_state = RunState(world_name, team_names, voie, profile_name=PROFILE_NAME)
    start_combat_screen(root, run_state)

def start_combat_screen(root, run_state):
    clear_window(root)
    root.configure(bg="#1e1e1e")
    tk.Label(root, text=f"{run_state.world_name} - Étape {run_state.floor} - Voie : {run_state.voie}",
             font=("Arial", 18), fg="#90caf9", bg="#1e1e1e").pack(pady=10)
    frame = tk.Frame(root, bg="#1e1e1e")
    frame.pack(expand=True, fill="both")
    allies_frame = tk.Frame(frame, bg="#1e1e1e")
    allies_frame.pack(side="left", expand=True, fill="both", padx=20)
    enemies_frame = tk.Frame(frame, bg="#1e1e1e")
    enemies_frame.pack(side="right", expand=True, fill="both", padx=20)
    tk.Label(allies_frame, text="Alliés", font=("Arial", 16), fg="#4fc3f7", bg="#1e1e1e").pack(anchor="w")
    tk.Label(enemies_frame, text="Ennemis", font=("Arial", 16), fg="#ef5350", bg="#1e1e1e").pack(anchor="w")
    allies_list_frame = tk.Frame(allies_frame, bg="#1e1e1e")
    allies_list_frame.pack(anchor="w", pady=10)
    enemies_list_frame = tk.Frame(enemies_frame, bg="#1e1e1e")
    enemies_list_frame.pack(anchor="w", pady=10)
    log_box = tk.Text(root, height=10, bg="#121212", fg="white", font=("Arial", 11))
    log_box.pack(fill="both", padx=10, pady=10)
    battle = BattleSystem(root, run_state.voie, log_box, allies_list_frame, enemies_list_frame,
                          team_names=run_state.team_names, run_state=run_state)
    battle.start_turn_cycle()
    tk.Button(root, text="Quitter le combat", font=("Arial", 12),
              command=lambda: open_menu(root)).pack(pady=5)

def open_benediction_choice(root, run_state):
    clear_window(root)
    root.configure(bg="#1e1e1e")
    from benediction import BENEDICTIONS as ALL_BEN
    choices = random.sample(ALL_BEN, min(3, len(ALL_BEN))) if ALL_BEN else []
    tk.Label(root, text="Choisissez une Bénédiction", font=("Arial", 24),
             fg="white", bg="#1e1e1e").pack(pady=20)
    frame = tk.Frame(root, bg="#1e1e1e")
    frame.pack(pady=10)
    def pick_benediction(b):
        run_state.benedictions.append(b)
        autosave_run(run_state.profile_name, run_state)
        start_zone_select(root, run_state)
    if not choices:
        tk.Label(frame, text="Aucune bénédiction disponible.", fg="white", bg="#1e1e1e").pack()
        tk.Button(root, text="Continuer", command=lambda: start_zone_select(root, run_state)).pack(pady=10)
        return
    for b in choices:
        txt = f"{b.name} — {b.chemin}\n{b.description}"
        tk.Button(frame, text=txt, font=("Arial", 12), width=40, wraplength=400,
                  command=lambda bb=b: pick_benediction(bb)).pack(pady=6)

def start_zone_select(root, run_state):
    clear_window(root)
    root.configure(bg="#1e1e1e")
    tk.Label(root, text="Choisissez une zone", font=("Arial", 24), fg="white", bg="#1e1e1e").pack(pady=20)
    frame = tk.Frame(root, bg="#1e1e1e")
    frame.pack(pady=10)
    for z in ZONES:
        def on_click(zone=z):
            if zone.type == "combat":
                run_state.elite = False
                run_state.conversion = False
                start_combat_screen(root, run_state)
            elif zone.type == "elite":
                run_state.elite = True
                run_state.conversion = False
                start_combat_screen(root, run_state)
            elif zone.type == "conversion":
                run_state.conversion = True
                run_state.elite = False
                start_combat_screen(root, run_state)
            elif zone.type == "shop":
                open_shop(root, run_state)
            elif zone.type == "event":
                open_event_screen(root, run_state)
        tk.Button(frame, text=f"{z.name} ({z.type})", font=("Arial", 14), width=30, command=on_click).pack(pady=6)

def open_event_screen(root, run_state):
    clear_window(root)
    root.configure(bg="#1e1e1e")
    tk.Label(root, text="Évènement", font=("Arial", 24), fg="white", bg="#1e1e1e").pack(pady=10)
    frame = tk.Frame(root, bg="#1e1e1e")
    frame.pack(pady=10)
    for ev in EVENTS:
        tk.Button(frame, text=ev, font=("Arial", 16), width=30,
                  command=lambda e=ev: choose_event(root, run_state, e)).pack(pady=5)

def choose_event(root, run_state, event_name):
    if event_name == "Voyageur Minérale":
        run_state.bonus_hp += 20
    elif event_name == "Voyageur Chanceux":
        run_state.bonus_crit += 0.06
    elif event_name == "Voyageur Perçant":
        run_state.bonus_atk_mult *= 1.03
    autosave_run(run_state.profile_name, run_state)
    start_combat_screen(root, run_state)

def open_shop(root, run_state):
    clear_window(root)
    root.configure(bg="#1e1e1e")
    tk.Label(root, text=f"Marchand — Diamants : {run_state.diamants}", font=("Arial", 22), fg="white", bg="#1e1e1e").pack(pady=20)
    frame = tk.Frame(root, bg="#1e1e1e")
    frame.pack()
    def buy(stat):
        if run_state.diamants < 50:
            return
        run_state.diamants -= 50
        if stat == "bonus_atk_mult":
            run_state.bonus_atk_mult *= 1.05
        elif stat == "bonus_hp":
            run_state.bonus_hp += 10
        autosave_run(run_state.profile_name, run_state)
        start_zone_select(root, run_state)
    tk.Button(frame, text="Augmenter ATQ d’un allié (50)", font=("Arial", 16),
              command=lambda: buy("bonus_atk_mult")).pack(pady=10)
    tk.Button(frame, text="Augmenter PV Max d’un allié (50)", font=("Arial", 16),
              command=lambda: buy("bonus_hp")).pack(pady=10)

# ----------------------------
# Main entry
# ----------------------------
if __name__ == "__main__":
    root = tk.Tk()
    root.title("Simulation Universel (BETA)")
    root.geometry("900x650")
    open_menu(root)
    root.mainloop()
