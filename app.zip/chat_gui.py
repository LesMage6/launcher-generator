import tkinter as tk
import os
import time
import threading

MESSAGES_FILE = "messages.txt"
USERNAME = "User"  # tu pourras le lier au profil plus tard

def read_messages():
    if not os.path.exists(MESSAGES_FILE):
        return []
    with open(MESSAGES_FILE, "r", encoding="utf-8") as f:
        return f.readlines()

def write_message(text):
    with open(MESSAGES_FILE, "a", encoding="utf-8") as f:
        f.write(text + "\n")

def open_chat():
    root = tk.Tk()
    root.title("Messagerie de Groupe")
    root.geometry("500x400")

    # Zone d'affichage
    messages_box = tk.Text(root, state="disabled", wrap="word")
    messages_box.pack(fill="both", expand=True)

    # Zone de saisie
    entry = tk.Entry(root)
    entry.pack(fill="x", padx=5, pady=5)
    entry.focus_set()  # IMPORTANT : active l'input

    def refresh_messages():
        last_content = ""
        while True:
            time.sleep(1)
            msgs = read_messages()
            content = "".join(msgs)
            if content != last_content:
                messages_box.config(state="normal")
                messages_box.delete("1.0", tk.END)
                messages_box.insert(tk.END, content)
                messages_box.config(state="disabled")
                messages_box.see(tk.END)
                last_content = content

    def send_message(event=None):
        msg = entry.get().strip()
        if msg:
            write_message(f"[{USERNAME}] {msg}")
            entry.delete(0, tk.END)

    # Envoi avec Entrée
    entry.bind("<Return>", send_message)

    # Envoi avec bouton
    tk.Button(root, text="Envoyer", command=send_message).pack(pady=5)

    # Thread de rafraîchissement
    threading.Thread(target=refresh_messages, daemon=True).start()

    root.mainloop()