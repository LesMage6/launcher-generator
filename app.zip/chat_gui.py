import tkinter as tk
import os
import time
import threading

MESSAGES_FILE = "messages.txt"

def read_messages():
    if not os.path.exists(MESSAGES_FILE):
        return []
    with open(MESSAGES_FILE, "r", encoding="utf-8") as f:
        return f.readlines()

def write_message(text):
    with open(MESSAGES_FILE, "a", encoding="utf-8") as f:
        f.write(text + "\n")

def open_chat():
    root = tk.Tk()
    root.title("Messagerie de Groupe")
    root.geometry("500x400")

    messages_box = tk.Text(root, state="disabled", wrap="word")
    messages_box.pack(fill="both", expand=True)

    entry = tk.Entry(root)
    entry.pack(fill="x", padx=5, pady=5)

    def refresh_messages():
        while True:
            time.sleep(2)
            msgs = read_messages()
            messages_box.config(state="normal")
            messages_box.delete("1.0", tk.END)
            for m in msgs:
                messages_box.insert(tk.END, m)
            messages_box.config(state="disabled")

    def send_message():
        msg = entry.get().strip()
        if msg:
            write_message(msg)
            entry.delete(0, tk.END)

    tk.Button(root, text="Envoyer", command=send_message).pack()

    threading.Thread(target=refresh_messages, daemon=True).start()

    root.mainloop()