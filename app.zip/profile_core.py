import json
import os
import uuid

PROFILE_DIR = "profiles"
os.makedirs(PROFILE_DIR, exist_ok=True)

def generate_profile_id():
    return "MG-" + uuid.uuid4().hex[:8].upper()

def list_profiles():
    return [f[:-5] for f in os.listdir(PROFILE_DIR) if f.endswith(".json")]

def create_profile(name):
    path = f"{PROFILE_DIR}/{name}.json"
    if os.path.exists(path):
        return "Ce profil existe déjà."

    data = {
        "id": generate_profile_id(),
        "favorite_origin": "fr",
        "favorite_gender": "M",
        "preferred_rarity": "SSR",
        "style": "default",
        "mage_coins": 0,
        "last_coin_time": 0
    }

    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

    return f"Profil '{name}' créé."

def load_profile(name):
    path = f"{PROFILE_DIR}/{name}.json"
    if not os.path.exists(path):
        return "Profil introuvable."

    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)