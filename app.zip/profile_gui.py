import tkinter as tk
from tkinter import messagebox
import json
import os
from profile_core import PROFILE_DIR, create_profile, load_profile, list_profiles

def open_profile_manager():
    root = tk.Tk()
    root.title("Gestion des Profils")
    root.geometry("500x350")

    # --- LISTE DES PROFILS ---
    tk.Label(root, text="Profils disponibles :", font=("Arial", 14)).pack(pady=5)

    listbox = tk.Listbox(root, font=("Arial", 12))
    listbox.pack(fill="both", expand=True, padx=10)

    def refresh_list():
        listbox.delete(0, tk.END)
        for p in list_profiles():
            listbox.insert(tk.END, p)

    refresh_list()

    # --- AFFICHAGE DES INFOS ---
    info_label = tk.Label(root, text="Sélectionnez un profil", font=("Arial", 12))
    info_label.pack(pady=5)

    def show_info(event=None):
        if not listbox.curselection():
            return
        name = listbox.get(listbox.curselection()[0])
        with open(f"{PROFILE_DIR}/{name}.json", "r", encoding="utf-8") as f:
            data = json.load(f)

        info_label.config(text=f"ID : {data['id']}\nCoins : {data['mage_coins']}")

    listbox.bind("<<ListboxSelect>>", show_info)

    # --- BOUTONS ---
    frame = tk.Frame(root)
    frame.pack(pady=10)

    # Créer un profil
    def create():
        win = tk.Toplevel(root)
        win.title("Créer un profil")
        win.geometry("300x120")

        tk.Label(win, text="Nom du profil :").pack()
        entry = tk.Entry(win)
        entry.pack()

        def validate():
            name = entry.get().strip()
            if not name:
                messagebox.showerror("Erreur", "Nom invalide.")
                return
            msg = create_profile(name)
            messagebox.showinfo("Info", msg)
            refresh_list()
            win.destroy()

        tk.Button(win, text="Créer", command=validate).pack(pady=5)

    # Charger un profil
    def load():
        if not listbox.curselection():
            messagebox.showerror("Erreur", "Sélectionnez un profil.")
            return
        name = listbox.get(listbox.curselection()[0])
        msg = load_profile(name)
        messagebox.showinfo("Info", msg)

    # Supprimer un profil
    def delete():
        if not listbox.curselection():
            messagebox.showerror("Erreur", "Sélectionnez un profil.")
            return
        name = listbox.get(listbox.curselection()[0])
        os.remove(f"{PROFILE_DIR}/{name}.json")
        refresh_list()
        info_label.config(text="Sélectionnez un profil")

    tk.Button(frame, text="Créer", width=10, command=create).grid(row=0, column=0, padx=5)
    tk.Button(frame, text="Charger", width=10, command=load).grid(row=0, column=1, padx=5)
    tk.Button(frame, text="Supprimer", width=10, command=delete).grid(row=0, column=2, padx=5)

    root.mainloop()