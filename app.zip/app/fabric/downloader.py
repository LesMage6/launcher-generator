import requests
import zipfile
import os
import shutil

CACHE_DIR = "fabric/cache/"
MODS_DIR = "fabric/mods/"
TEMP_DIR = "fabric/cache/temp/"

os.makedirs(CACHE_DIR, exist_ok=True)
os.makedirs(MODS_DIR, exist_ok=True)
os.makedirs(TEMP_DIR, exist_ok=True)

def download_file(url, dest, progress_callback=None):
    r = requests.get(url, stream=True)
    total = int(r.headers.get("content-length", 0))
    downloaded = 0

    with open(dest, "wb") as f:
        for chunk in r.iter_content(chunk_size=1024):
            if chunk:
                f.write(chunk)
                downloaded += len(chunk)
                if progress_callback:
                    progress_callback(downloaded, total)

def extract_zip(zip_path, extract_to):
    with zipfile.ZipFile(zip_path, "r") as zip_ref:
        zip_ref.extractall(extract_to)

def install_mod(temp_path, mod_name):
    for item in os.listdir(temp_path):
        src = os.path.join(temp_path, item)
        dst = os.path.join(MODS_DIR, item)

        if os.path.exists(dst):
            os.remove(dst)

        shutil.move(src, dst)

    shutil.rmtree(temp_path)
    os.makedirs(temp_path, exist_ok=True)