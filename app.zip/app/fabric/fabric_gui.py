import tkinter as tk
from tkinter import ttk
import requests
import json
import os

from fabric.downloader import download_file, extract_zip, install_mod, CACHE_DIR, TEMP_DIR

MODS_URL = "https://raw.githubusercontent.com/TonCompte/LauncherServer/main/mods_officiels.json"

def open_fabric_gui():
    root = tk.Tk()
    root.title("Fabric Mod Manager")
    root.geometry("500x400")

    tk.Label(root, text="Mods officiels Fabric", font=("Arial", 16)).pack(pady=10)

    frame = tk.Frame(root)
    frame.pack(fill="both", expand=True)

    scrollbar = tk.Scrollbar(frame)
    scrollbar.pack(side="right", fill="y")

    listbox = tk.Listbox(frame, yscrollcommand=scrollbar.set, font=("Arial", 12))
    listbox.pack(side="left", fill="both", expand=True)
    scrollbar.config(command=listbox.yview)

    progress = ttk.Progressbar(root, length=400)
    progress.pack(pady=10)

    status = tk.Label(root, text="Prêt", font=("Arial", 12))
    status.pack()

    # Charger la liste des mods
    try:
        r = requests.get(MODS_URL)
        mods = r.json()
    except:
        status.config(text="Erreur : impossible de charger les mods.")
        return

    # Ajouter les mods dans la liste
    for key, mod in mods.items():
        listbox.insert(tk.END, f"{mod['name']} (v{mod['version']})")

    def install_selected_mod():
        index = listbox.curselection()
        if not index:
            status.config(text="Sélectionne un mod.")
            return

        mod_key = list(mods.keys())[index[0]]
        mod = mods[mod_key]

        status.config(text=f"Téléchargement de {mod['name']}...")

        zip_path = os.path.join(CACHE_DIR, f"{mod_key}.zip")

        def update_progress(downloaded, total):
            if total > 0:
                progress["value"] = (downloaded / total) * 100
                root.update_idletasks()

        download_file(mod["url"], zip_path, update_progress)

        status.config(text="Extraction...")
        extract_zip(zip_path, TEMP_DIR)

        status.config(text="Installation...")
        install_mod(TEMP_DIR, mod_key)

        status.config(text=f"{mod['name']} installé !")
        progress["value"] = 0

    tk.Button(root, text="Installer le mod sélectionné", command=install_selected_mod).pack(pady=10)

    root.mainloop()