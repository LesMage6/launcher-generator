import requests
import json

SERVER_VERSION_URL = "https://raw.githubusercontent.com/LesMage6/launcher-generator/main/version.json"

def get_local_version():
    try:
        with open("config.json", "r", encoding="utf-8") as f:
            config = json.load(f)
            return config.get("app_version", "0.0.0")
    except FileNotFoundError:
        return "0.0.0"

def get_server_version():
    try:
        r = requests.get(SERVER_VERSION_URL)
        return r.json()
    except:
        return None

def is_update_available():
    local = get_local_version()
    server = get_server_version()

    if not server:
        return False, None

    return server["version"] != local, server