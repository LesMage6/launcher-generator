import requests
import zipfile
import shutil
import os
import json

APP_DOWNLOAD_PATH = "update/app.zip"
APP_EXTRACT_PATH = "update/temp/"

def download_update(url):
    os.makedirs("update", exist_ok=True)
    r = requests.get(url)

    with open(APP_DOWNLOAD_PATH, "wb") as f:
        f.write(r.content)

def extract_update():
    with zipfile.ZipFile(APP_DOWNLOAD_PATH, "r") as zip_ref:
        zip_ref.extractall(APP_EXTRACT_PATH)

def install_update():
    for item in os.listdir(APP_EXTRACT_PATH):
        src = os.path.join(APP_EXTRACT_PATH, item)
        dst = os.path.join(".", item)

        if os.path.isdir(src):
            if os.path.exists(dst):
                shutil.rmtree(dst)
            shutil.move(src, dst)
        else:
            shutil.move(src, dst)

def update_local_version(version):
    with open("config.json", "r", encoding="utf-8") as f:
        config = json.load(f)

    config["app_version"] = version

    with open("config.json", "w", encoding="utf-8") as f:
        json.dump(config, f, indent=4, ensure_ascii=False)
