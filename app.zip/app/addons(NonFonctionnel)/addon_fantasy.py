def apply(data):
    data["names"]["fr"]["M"].extend(["Aldren", "Faelan", "Thorian"])
    data["names"]["fr"]["F"].extend(["Lyanna", "Seraphine", "Elyndra"])

def register():
    return {
        "name": "Fantasy Names",
        "description": "Ajoute des noms fantasy.",
        "version": "1.0",
        "author": "LM6",
        "apply": apply
    }
